#include <iostream>
#include <cmath>

int main()
{
	int a = 324;
	int b = 344;
	int c = 345;
	int d = 324;
	double g = 3.1415;
	int tot= a + b - c * d / g;
	
	std::cout << a << "\n";
	std::cout << b << "\n";
	std::cout << c << "\n";
	std::cout << d << "\n";
	std::cout << g << "\n";
	std::cout << tot << "\n";
	
	return 0;
}