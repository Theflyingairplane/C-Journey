#include <iostream>
#include <cmath>
#include <array>
#include <vector>

int main()
{
	double balance = 155.50;
	double script;
	
	balance >= 150 ? std::cout << "Not in debt." : std::cout << "You're in debt." << std::endl;
	
	script = balance + 5;
	
	balance >= 150 ? std::cout << "Not in debt." : std::cout << "You're in debt." << std::endl;
	
	return 0;
}