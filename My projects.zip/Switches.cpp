#include <iostream>
#include <cmath>

int main()
{
	int num;
	
	std::cout << "Please pick a number from one to ten!";
	std::cin >> num;
	
	switch(num){
		case 1:
			std::cout << "One";
			break;
		case 2:
			std::cout << "Two";
			break;	
		case 3:
			std::cout << "Three";
			break;
		case 4:
			std::cout << "Four";
			break;	
		case 5:
			std::cout << "Five";
			break;
		case 6:
			std::cout << "Six";
			break;	
		case 7:
			std::cout << "Seven";
			break;
		case 8:
			std::cout << "Eight";
			break;	
		case 9:
			std::cout << "Nine";
			break;
		case 10:
			std::cout << "Ten";
			break;	
		default:
			std::cout << "Did you seriously just, ARE YOU SERIOUS.";
	}
	
	return 0;
}