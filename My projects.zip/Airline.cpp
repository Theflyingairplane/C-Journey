#include <iostream>

int main(){
	
	std::string tran;
	
	std::cout << "What's your airline?";
	std::cin >> tran;
	
	std::cout << "Can I catch a quick flight to RockVille on " << tran;
	
	return 0;
}