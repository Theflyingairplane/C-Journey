#include <iostream>
#include <cmath>

int main()
{
	std::cout << "This is the pythagorean theorem." << '\n';
	int a = 12;
	int b = 20;
	int sa = 12 * 12;
	int sb = 20 * 20;
	int hyp = sb - sa;
	
	std::cout << hyp << " is the hypotenuse." << '\n';
	std::cout << "Hyptonuse equals " << hyp << " And that's all folks.'" << '\n';
	
}