#include <iostream>
#include <cmath>

int main()
{
	double weight;
	double coff;
	double aea; 
	double bla;
	double pot;
	
	
	std::cout << "What is your projectile's weight?" << '\n';
	std::cin >> weight;
	
	std::cout << "Drag coefficient is?" << '\n';
	std::cin >> coff;
	
	std::cout << "The thing's area is?" << '\n';
	std::cin >> aea;

	bla = coff * aea;
	pot = weight / bla;
	
	std::cout << "The coefficient is! " << pot << " whatever measurement unit here." << '\n';
	
	
}