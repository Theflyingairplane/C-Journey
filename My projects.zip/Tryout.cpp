#include <iostream>
#include <cmath>

int main() {
    int balance;
    std::cout << "Enter your present balance and we'll see what can be done with your money: ";
    std::cin >> balance;

    if (balance <= 100) {
        std::cout << "Go buy yourself some pizza?" << std::endl;
    } else if (balance <= 200) {
        std::cout << "Buy some sandwiches. Probably footlongs." << std::endl;
    } else if (balance <= 300) {
        std::cout << "Go out to a restaurant." << std::endl;
    } else if (balance <= 400) {
        std::cout << "Go out to a better restaurant." << std::endl;
    } else if (balance <= 500) {
        std::cout << "Grocery shopping anyone? Or a new phone!" << std::endl;
    } else if (balance <= 600) {
        std::cout << "Even more grocery shopping!" << std::endl;
    } else if (balance <= 700) {
        std::cout << "Buy something you know you'll like." << std::endl;
    } else if (balance <= 800) {
        std::cout << "Buy something you'll really like." << std::endl;
    } else if (balance <= 900) {
        std::cout << "Save it." << std::endl;
    } else if (balance <= 1000) {
        std::cout << "Go to the bank and save it." << std::endl;
    } else {
        std::cout << "I don't know anymore." << std::endl;
    }

    return 0;
}
